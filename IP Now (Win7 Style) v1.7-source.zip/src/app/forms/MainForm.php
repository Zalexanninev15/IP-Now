<?php
namespace app\forms;

use php\lib\str;
use php\io\Stream;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 


class MainForm extends AbstractForm
{



    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $ipInfo = json_decode(Stream::getContents('http://ipinfo.io/json'), true); 
        $this->textArea->text = $ipInfo['ip'];
    }



}
