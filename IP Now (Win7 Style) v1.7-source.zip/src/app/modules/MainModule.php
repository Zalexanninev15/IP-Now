<?php
namespace app\modules;

use php\gui\framework\AbstractModule;


class MainModule extends AbstractModule
{

}